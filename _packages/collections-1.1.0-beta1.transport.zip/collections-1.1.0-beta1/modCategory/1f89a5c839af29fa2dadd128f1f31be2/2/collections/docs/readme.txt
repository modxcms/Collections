=====================
     Collections
     1.0.0 pl

      Jan Peca
  pecajan@gmail.com
=====================

An Extra for MODX Revolution that provides for Resource Collections managed by CollectionContainer Resources.