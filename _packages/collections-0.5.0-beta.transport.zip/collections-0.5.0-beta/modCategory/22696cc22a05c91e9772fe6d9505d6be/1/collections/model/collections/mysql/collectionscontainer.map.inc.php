<?php
/**
 * @package collections
 */
$xpdo_meta_map['CollectionsContainer']= array (
  'package' => 'collections',
  'version' => NULL,
  'extends' => 'modResource',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
