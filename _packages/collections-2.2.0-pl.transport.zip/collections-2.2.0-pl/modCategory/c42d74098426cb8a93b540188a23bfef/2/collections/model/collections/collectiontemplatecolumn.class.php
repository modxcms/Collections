<?php
/**
 *
 * @property int $id
 * @property int $template
 * @property string $name
 * @property string $label
 * @property bool $hidden
 * @property bool $sortable
 * @property int $width
 *
 * @property CollectionTemplate $Template
 *
 * @package collections
 */
class CollectionTemplateColumn extends xPDOSimpleObject {}
?>