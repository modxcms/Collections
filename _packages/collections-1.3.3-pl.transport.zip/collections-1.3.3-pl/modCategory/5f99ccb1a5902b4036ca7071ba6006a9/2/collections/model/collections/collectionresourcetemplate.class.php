<?php
/**
 * @package collections
 */
class CollectionResourceTemplate extends xPDOObject {}
?>