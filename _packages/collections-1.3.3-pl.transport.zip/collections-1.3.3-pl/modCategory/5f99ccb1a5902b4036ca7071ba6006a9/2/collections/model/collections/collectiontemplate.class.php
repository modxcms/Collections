<?php
/**
 *
 * @property int $id
 * @property string $name
 * @property string $description
 *
 * @property CollectionSetting $Setting
 * @property CollectionTemplateColumn $Columns
 *
 * @package collections
 */
class CollectionTemplate extends xPDOSimpleObject {}
?>