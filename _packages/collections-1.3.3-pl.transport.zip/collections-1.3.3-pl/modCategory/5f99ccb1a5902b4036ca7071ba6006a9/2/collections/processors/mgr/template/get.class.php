<?php
/**
 * Get Template
 *
 * @package collections
 * @subpackage processors
 */
class CollectionsTemplateGetProcessor extends modObjectGetProcessor {
    public $classKey = 'CollectionTemplate';
    public $languageTopics = array('collections:default');
    public $objectType = 'collections.template';

}
return 'CollectionsTemplateGetProcessor';