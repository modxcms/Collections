<?php
/**
 * Get list Template columns
 *
 * @package collections
 * @subpackage processors
 */
class CollectionsTemplateColumnGetListProcessor extends modObjectGetListProcessor {
    public $classKey = 'CollectionTemplateColumn';
    public $languageTopics = array('collections:default');
    public $defaultSortField = 'id';
    public $defaultSortDirection = 'ASC';
    public $objectType = 'collections.template.column';

}
return 'CollectionsTemplateColumnGetListProcessor';