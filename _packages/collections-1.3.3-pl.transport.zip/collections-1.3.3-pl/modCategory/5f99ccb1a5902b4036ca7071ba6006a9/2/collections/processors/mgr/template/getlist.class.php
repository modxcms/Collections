<?php
/**
 * Get list Templates
 *
 * @package collections
 * @subpackage processors
 */
class CollectionsTemplateGetListProcessor extends modObjectGetListProcessor {
    public $classKey = 'CollectionTemplate';
    public $languageTopics = array('collections:default');
    public $defaultSortField = 'name';
    public $defaultSortDirection = 'ASC';
    public $objectType = 'collections.template';

}
return 'CollectionsTemplateGetListProcessor';