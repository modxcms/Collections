Collections.panel.Template = function(config) {
    config = config || {};
    Ext.applyIf(config,{
        border: false
        ,id: 'collections-panel-template'
        ,cls: 'container'
        ,url: Collections.config.connectorUrl
        ,baseParams: {
            action: 'mgr/template/create'
        }
        ,useLoadingMask: true
        ,items: [{
            html: '<h2>' + ((config.isUpdate == true)? _('collections.template.update_template') : _('collections.template.new_template')) + '</h2>'
            ,border: false
            ,cls: 'modx-page-header'
        },{
            name: 'id'
            ,xtype: 'hidden'
        },
            this.getItems(config)
        , {
                html: '<br />'
                ,bodyCssClass: 'transparent-background'
            }, this.getColumnsGrid(config)
        ]
        ,listeners: {
            'setup': {
                fn: this.setup
                ,scope: this
            }
            ,'success': {
                fn: this.success
                ,scope: this
            }
        }
    });
    Collections.panel.Template.superclass.constructor.call(this, config);
};

Ext.extend(Collections.panel.Template, MODx.FormPanel,{
    setup: function() {
        if (this.config.isUpdate) {
            MODx.Ajax.request({
                url: this.config.url
                ,params: {
                    action: 'mgr/template/get'
                    ,id: MODx.request.id
                },
                listeners: {
                    'success': {
                        fn: function(r) {
                            this.getForm().setValues(r.object);

                            this.fireEvent('ready', r.object);
                            MODx.fireEvent('ready');
                        },
                        scope: this
                    }
                }
            });
        } else {
            this.fireEvent('ready');
            MODx.fireEvent('ready');
        }
    }


    ,success: function(o, r) {
        MODx.loadPage('template/update', 'namespace=collections&id='+ o.result.object.id);
    }

    ,getItems: function(config){
        var items = [{
            deferredRender: false
            ,border: true
            ,defaults: {
                autoHeight: true
                ,layout: 'form'
                ,labelWidth: 150
                ,bodyCssClass: 'main-wrapper'
                ,layoutOnTabChange: true
            }
            ,items: [{
                defaults: {
                    msgTarget: 'side'
                    ,autoHeight: true
                }
                ,cls: 'form-with-labels'
                ,border: false
                ,items: [{
                    layout: 'column'
                    ,border: false
                    ,height: 100
                    ,defaults: {
                        layout: 'form'
                        ,labelAlign: 'top'
                        ,labelSeparator: ''
                        ,anchor: '100%'
                        ,border: false
                    }
                    ,items: [{
                        columnWidth: 0.7
                        ,border: false
                        ,defaults: {
                            msgTarget: 'under'
                        }
                        ,items: [{
                            xtype: 'textfield'
                            ,fieldLabel: _('collections.template.name')
                            ,name: 'name'
                            ,anchor: '100%'
                            ,allowBlank: false
                        },{
                            xtype: 'textarea'
                            ,fieldLabel: _('collections.template.description')
                            ,name: 'description'
                            ,anchor: '100%'
                        }]
                    },{
                        columnWidth: 0.3
                        ,border: false
                        ,defaults: {
                            msgTarget: 'under'
                        }
                        ,items: []
                    }]
                }]
            }]
        }];

        return items;
    }

    ,getColumnsGrid: function(config) {
        var items = [{
            deferredRender: false
            ,border: true
            ,defaults: {
                autoHeight: true
                ,layout: 'form'
                ,labelWidth: 150
                ,bodyCssClass: 'main-wrapper'
                ,layoutOnTabChange: true
            }
            ,items: [{
                defaults: {
                    msgTarget: 'side'
                    ,autoHeight: true
                }
                ,cls: 'form-with-labels'
                ,border: false
                ,items: [{
                    layout: 'column'
                    ,border: false
                    ,height: 100
                    ,defaults: {
                        layout: 'form'
                        ,labelAlign: 'top'
                        ,labelSeparator: ''
                        ,anchor: '100%'
                        ,border: false
                    }
                    ,items: [{
                        columnWidth: 1
                        ,border: false
                        ,defaults: {
                            msgTarget: 'under'
                        }
                        ,items: [{
                            xtype: 'collections-grid-template-column'
                        }]
                    }]
                }]
            }]
        }];

        return items;
    }
});
Ext.reg('collections-panel-template',Collections.panel.Template);