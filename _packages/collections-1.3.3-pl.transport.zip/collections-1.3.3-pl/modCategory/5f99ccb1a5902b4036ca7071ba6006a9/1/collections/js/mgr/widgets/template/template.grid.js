Collections.grid.Template = function(config) {
    config = config || {};
    Ext.applyIf(config,{
        title: _('collections.collections')
        ,url: Collections.config.connectorUrl
        ,autosave: true
//        ,save_action: 'mgr/resource/updatefromgrid'
        ,baseParams: {
            action: 'mgr/template/getList'
            ,'template': 1
        }
        ,fields: ['id','name', 'description']
        ,paging: true
        ,remoteSort: true
        ,emptyText: _('collections.template.none')
        ,columns: [{
            header: _('collections.template.name')
            ,dataIndex: 'name'
            ,sortable: true
        },{
            header: _('collections.template.description')
            ,dataIndex: 'description'
            ,sortable: true
        }]
        ,tbar: [{
            text: _('collections.template.add')
            ,handler: this.createChild
            ,scope: this
        }]
    });
    Collections.grid.Template.superclass.constructor.call(this,config);
};
Ext.extend(Collections.grid.Template,MODx.grid.Grid,{
    getMenu: function() {
        var m = [];

        m.push({
            text: _('collections.children.update')
            ,handler: this.editTemplate
        });
        m.push({
            text: _('collections.children.delete')
            ,handler: this.deleteChild
        });
        return m;
    }

    ,editTemplate: function() {
        MODx.loadPage('template/update', 'namespace=collections&id='+ this.menu.record.id);
    }

});
Ext.reg('collections-grid-template',Collections.grid.Template);