Collections.grid.TemplateColumn = function(config) {
    config = config || {};
    Ext.applyIf(config,{
        url: Collections.config.connectorUrl
        ,autosave: true
//        ,save_action: 'mgr/resource/updatefromgrid'
        ,baseParams: {
            action: 'mgr/template/column/getList'
            ,'template': MODx.request.id
        }
        ,fields: ['id','name', 'label']
        ,paging: true
        ,remoteSort: true
        ,emptyText: _('collections.template.column.none')
        ,columns: [{
            header: _('collections.template.column.label')
            ,dataIndex: 'label'
            ,sortable: true
        },{
            header: _('collections.template.column.name')
            ,dataIndex: 'name'
            ,sortable: true
        }]
        ,tbar: [{
            text: _('collections.template.column.add')
            ,handler: this.createChild
            ,scope: this
        }]
    });
    Collections.grid.TemplateColumn.superclass.constructor.call(this,config);
};
Ext.extend(Collections.grid.TemplateColumn,MODx.grid.Grid,{
    getMenu: function() {
        var m = [];

        m.push({
            text: _('collections.children.update')
            ,handler: this.editTemplate
        });
        m.push({
            text: _('collections.children.delete')
            ,handler: this.deleteChild
        });
        return m;
    }

});
Ext.reg('collections-grid-template-column',Collections.grid.TemplateColumn);