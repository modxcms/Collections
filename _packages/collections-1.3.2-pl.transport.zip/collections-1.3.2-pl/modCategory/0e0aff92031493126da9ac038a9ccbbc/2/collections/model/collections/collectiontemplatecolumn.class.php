<?php
/**
 *
 * @property int $id
 * @property int $template
 * @property string $name
 * @property bool $hidden
 *
 * @property CollectionTemplate $Template
 *
 * @package collections
 */
class CollectionTemplateColumn extends xPDOSimpleObject {}
?>