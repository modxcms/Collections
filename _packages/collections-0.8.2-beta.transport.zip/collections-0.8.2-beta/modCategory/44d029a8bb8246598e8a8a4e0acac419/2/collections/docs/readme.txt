=====================
     Collections
     0.8.1 beta

      Jan Peca
  pecajan@gmail.com
=====================

An Extra for MODX Revolution that provides for Resource Collections managed by CollectionContainer Resources.