<?php
require_once dirname(dirname(__FILE__)) . '/data.class.php';

/**
 * Loads the collection data page
 *
 * @package collections
 * @subpackage controllers
 */
class SelectionContainerDataManagerController extends CollectionContainerDataManagerController {}
