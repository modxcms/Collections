<?php

$xpdo_meta_map = array (
  'modResource' => 
  array (
    0 => 'CollectionContainer',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'CollectionSetting',
    1 => 'CollectionTemplate',
    2 => 'CollectionTemplateColumn',
  ),
);