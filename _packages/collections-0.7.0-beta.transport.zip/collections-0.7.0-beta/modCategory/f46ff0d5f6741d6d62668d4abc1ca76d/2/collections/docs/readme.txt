=====================
     Collections
     0.7.0 alpha

      Jan Peca
  pecajan@gmail.com
=====================

An Extra for MODX Revolution that provides for Resource Collections managed by CollectionContainer Resources.