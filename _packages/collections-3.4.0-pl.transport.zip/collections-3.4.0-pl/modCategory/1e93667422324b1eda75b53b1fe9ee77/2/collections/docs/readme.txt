=====================
     Collections
     3.4.0 pl

      John Peca
     john@modx.com
=====================

An Extra for MODX Revolution that provides for Resource Collections managed by CollectionContainer Resources.